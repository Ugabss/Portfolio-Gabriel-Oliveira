document.addEventListener('DOMContentLoaded', () => {
    console.log('Site carregado com sucesso!');
});
